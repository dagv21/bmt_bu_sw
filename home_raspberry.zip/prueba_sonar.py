import time
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
GPIO_TRIGECHO=18
print ("medicion ultrasonica")
GPIO.setup(GPIO_TRIGECHO, GPIO.OUT)
GPIO.output(GPIO_TRIGECHO, False)
LED=24
GPIO.setup(LED,GPIO.OUT)

def medida():
        GPIO.output(GPIO_TRIGECHO, True)
        time.sleep(0.00001)
        GPIO.output(GPIO_TRIGECHO, False)
        inicio=time.time()
        GPIO.setup(GPIO_TRIGECHO, GPIO.IN)
        while GPIO.input(GPIO_TRIGECHO)==0:
                inicio=time.time()
                GPIO.output(LED, GPIO.HIGH)
        while GPIO.input(GPIO_TRIGECHO)==1:
                final=time.time()
                GPIO.output(LED, GPIO.HIGH)
        GPIO.setup(GPIO_TRIGECHO, GPIO.OUT)
        GPIO.output(GPIO_TRIGECHO, False)
        camino=final-inicio
        print("tiempo : %.7f s" %camino)
        distancia=(16637*camino)+2.4785
        time.sleep(0.1)
        return distancia
try:
        while True:
                distancia=medida()
                print(" distancia : %.1f cm" %distancia)
                time.sleep(1)
except:
        GPIO.output(LED, GPIO.HIGH)
        print("Final")
	GPIO.cleanup()


