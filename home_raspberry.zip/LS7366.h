#ifndef QuadratureCounterLibrary_H
#define QuadratureCounterLibrary_H


// #include <SPI.h>

class QuadratureCounterLibrary{

      public:
              QuadratureCounterLibrary(int* _slaveSelectEnc);
              // ~QuadratureCounterLibrary();

              //void initEncoder();
              // long readEncoder();
              // void clearEncoderCount();
              // void debugEncoder();

              // unsigned char encodercount[5] = {0x00, 0x00, 0x00, 0x00};

       private:
              int* slaveSelectEnc;
              // long EncoderActualValue(int usedPin);
              // void _clearEncoderCount(int usedPin);


};

#endif
