#import rospy
# from t_flex.msg import IMUData
from std_msgs.msg import Bool
import spidev
import smbus
import time
import numpy as np
import RPi.GPIO as GPIO

''' Commands'''
WRITE_MDR0 = 136 #0x88 #Write to MDR0
WRITE_DTR = 152 #0x98 #Write to DTR
DATA_TO_CENTER = 224 #0xE0 #Set encoder's current data register to center
REQUEST_COUNT = 96 #0x60 #Request count
READ_MDR0 = 72 #0x48 #Output MDR0
''' Modes '''
FOURX_COUNT = 3#0x03 #Configure to 4 byte mode

class Encoder(object):
    

    def __init__(self, SS_PINS=[23,24], PORT=0, CLOCK=1000000):
        self.ss_pins = SS_PINS
        GPIO.setmode(GPIO.BCM)
        self.spi = [] 
        ''' Open Connection'''
        for n in range(0,2):
            self.spi.append(spidev.SpiDev())
            self.spi[n].open(PORT,0)
            self.spi[n].max_speed_hz = CLOCK
            self.spi[n].no_cs = True
            GPIO.setup(self.ss_pins[n],GPIO.OUT)
            time.sleep(0.05)
            GPIO.output(self.ss_pins[n],1)
            time.sleep(0.1)
            GPIO.output(self.ss_pins[n],0)
            self.spi[n].writebytes([WRITE_MDR0,FOURX_COUNT])
            GPIO.output(self.ss_pins[n],1)
            #self.spi[n].xfer2([WRITE_MDR0,FOURX_COUNT])
            #self.clear_encoder_count(n)
            time.sleep(0.1)
            GPIO.output(self.ss_pins[n],0)
            self.spi[n].writebytes([READ_MDR0])
            print(self.spi[n].readbytes(1))
            GPIO.output(self.ss_pins[n],1)
            print("Device " + str(n+1) + " Configured")

    def clear_encoder_count(self,n):
        self.spi[n].xfer2([WRITE_DTR,0x00,0x00,0x00,0x00])
        time.sleep(0.1)
        self.spi[n].xfer([DATA_TO_CENTER])

    def read_data(self):
         for n in range(0,2):
            encodercount = []
            self.spi[n].xfer([REQUEST_COUNT])
            print(bytearray(self.spi[n].readbytes(4)))  #Read highest order byte
            #self.spi[n].xfer([0x00])
            #self.spi[n].xfer([0x00])
            #self.spi[n].xfer([0x00])   #Read lowest order byte
            print("Encoder : " + str(n) + " " + str(encodercount))

def main():
    e = Encoder(SS_PINS=[23,24], PORT=0, CLOCK=100000)
    #msg = Insole()
    #rate = rospy.Rate(200)
    #print('Reading FSR data, press Ctrl-C to quit...')
    #while not rospy.is_shutdown():
    try:
        while True:
            #e.read_data()
            time.sleep(0.4)
        # msg.header.frame_id = "/" + s.node_name
        # # msg.time_stamp = int(round((time.time() - s.start_time)*1000.0))
        # msg.toe = s.toe
        # msg.r_meta = s.r_meta
        # msg.l_meta = s.l_meta
        # msg.heel = s.heel
        # s.pub.publish(msg)
        # # time.sleep(0.5)
        # rate.sleep()
    except KeyboardInterrupt as err:
        #rospy.loginfo("Program Finished\n")
        e.spi[0].close()
        e.spi[1].close()
        print err
        #sys.stdout.close()
        raise

if __name__ == '__main__':
    main()

