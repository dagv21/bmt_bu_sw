// Auto-generated. Do not edit!

// (in-package bmt_bu_sw_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class IMUData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.time_stamp = null;
      this.quat_x = null;
      this.quat_y = null;
      this.quat_z = null;
      this.quat_w = null;
      this.gyro_x = null;
      this.gyro_y = null;
      this.gyro_z = null;
      this.accel_x = null;
      this.accel_y = null;
      this.accel_z = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = 0.0;
      }
      if (initObj.hasOwnProperty('quat_x')) {
        this.quat_x = initObj.quat_x
      }
      else {
        this.quat_x = 0.0;
      }
      if (initObj.hasOwnProperty('quat_y')) {
        this.quat_y = initObj.quat_y
      }
      else {
        this.quat_y = 0.0;
      }
      if (initObj.hasOwnProperty('quat_z')) {
        this.quat_z = initObj.quat_z
      }
      else {
        this.quat_z = 0.0;
      }
      if (initObj.hasOwnProperty('quat_w')) {
        this.quat_w = initObj.quat_w
      }
      else {
        this.quat_w = 0.0;
      }
      if (initObj.hasOwnProperty('gyro_x')) {
        this.gyro_x = initObj.gyro_x
      }
      else {
        this.gyro_x = 0.0;
      }
      if (initObj.hasOwnProperty('gyro_y')) {
        this.gyro_y = initObj.gyro_y
      }
      else {
        this.gyro_y = 0.0;
      }
      if (initObj.hasOwnProperty('gyro_z')) {
        this.gyro_z = initObj.gyro_z
      }
      else {
        this.gyro_z = 0.0;
      }
      if (initObj.hasOwnProperty('accel_x')) {
        this.accel_x = initObj.accel_x
      }
      else {
        this.accel_x = 0.0;
      }
      if (initObj.hasOwnProperty('accel_y')) {
        this.accel_y = initObj.accel_y
      }
      else {
        this.accel_y = 0.0;
      }
      if (initObj.hasOwnProperty('accel_z')) {
        this.accel_z = initObj.accel_z
      }
      else {
        this.accel_z = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type IMUData
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.float64(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [quat_x]
    bufferOffset = _serializer.float64(obj.quat_x, buffer, bufferOffset);
    // Serialize message field [quat_y]
    bufferOffset = _serializer.float64(obj.quat_y, buffer, bufferOffset);
    // Serialize message field [quat_z]
    bufferOffset = _serializer.float64(obj.quat_z, buffer, bufferOffset);
    // Serialize message field [quat_w]
    bufferOffset = _serializer.float64(obj.quat_w, buffer, bufferOffset);
    // Serialize message field [gyro_x]
    bufferOffset = _serializer.float64(obj.gyro_x, buffer, bufferOffset);
    // Serialize message field [gyro_y]
    bufferOffset = _serializer.float64(obj.gyro_y, buffer, bufferOffset);
    // Serialize message field [gyro_z]
    bufferOffset = _serializer.float64(obj.gyro_z, buffer, bufferOffset);
    // Serialize message field [accel_x]
    bufferOffset = _serializer.float64(obj.accel_x, buffer, bufferOffset);
    // Serialize message field [accel_y]
    bufferOffset = _serializer.float64(obj.accel_y, buffer, bufferOffset);
    // Serialize message field [accel_z]
    bufferOffset = _serializer.float64(obj.accel_z, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type IMUData
    let len;
    let data = new IMUData(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [quat_x]
    data.quat_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [quat_y]
    data.quat_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [quat_z]
    data.quat_z = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [quat_w]
    data.quat_w = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gyro_x]
    data.gyro_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gyro_y]
    data.gyro_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gyro_z]
    data.gyro_z = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [accel_x]
    data.accel_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [accel_y]
    data.accel_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [accel_z]
    data.accel_z = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 88;
  }

  static datatype() {
    // Returns string type for a message object
    return 'bmt_bu_sw_msgs/IMUData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3f87126d0df6b4d6358ce08ab926291d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Acquired IMU Data
    Header header
    float64 time_stamp
    float64 quat_x
    float64 quat_y
    float64 quat_z
    float64 quat_w
    float64 gyro_x
    float64 gyro_y
    float64 gyro_z
    float64 accel_x
    float64 accel_y
    float64 accel_z
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new IMUData(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = 0.0
    }

    if (msg.quat_x !== undefined) {
      resolved.quat_x = msg.quat_x;
    }
    else {
      resolved.quat_x = 0.0
    }

    if (msg.quat_y !== undefined) {
      resolved.quat_y = msg.quat_y;
    }
    else {
      resolved.quat_y = 0.0
    }

    if (msg.quat_z !== undefined) {
      resolved.quat_z = msg.quat_z;
    }
    else {
      resolved.quat_z = 0.0
    }

    if (msg.quat_w !== undefined) {
      resolved.quat_w = msg.quat_w;
    }
    else {
      resolved.quat_w = 0.0
    }

    if (msg.gyro_x !== undefined) {
      resolved.gyro_x = msg.gyro_x;
    }
    else {
      resolved.gyro_x = 0.0
    }

    if (msg.gyro_y !== undefined) {
      resolved.gyro_y = msg.gyro_y;
    }
    else {
      resolved.gyro_y = 0.0
    }

    if (msg.gyro_z !== undefined) {
      resolved.gyro_z = msg.gyro_z;
    }
    else {
      resolved.gyro_z = 0.0
    }

    if (msg.accel_x !== undefined) {
      resolved.accel_x = msg.accel_x;
    }
    else {
      resolved.accel_x = 0.0
    }

    if (msg.accel_y !== undefined) {
      resolved.accel_y = msg.accel_y;
    }
    else {
      resolved.accel_y = 0.0
    }

    if (msg.accel_z !== undefined) {
      resolved.accel_z = msg.accel_z;
    }
    else {
      resolved.accel_z = 0.0
    }

    return resolved;
    }
};

module.exports = IMUData;
