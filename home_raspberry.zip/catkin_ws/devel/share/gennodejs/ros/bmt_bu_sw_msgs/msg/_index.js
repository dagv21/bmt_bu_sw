
"use strict";

let IMUData = require('./IMUData.js');

module.exports = {
  IMUData: IMUData,
};
