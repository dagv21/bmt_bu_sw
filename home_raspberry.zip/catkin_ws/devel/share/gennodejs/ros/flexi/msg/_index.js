
"use strict";

let flexi = require('./flexi.js');

module.exports = {
  flexi: flexi,
};
