#include <hdetect/lib/header.hpp>

namespace Header
{
    float curTimestamp = -1;
    float preTimestamp = -1;
}
